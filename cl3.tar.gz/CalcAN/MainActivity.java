package com.example.lap_210.calculator;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText input1, input2;
    TextView tv;
    double result, no1, no2;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    public static final String key="key";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input1 = findViewById(R.id.no1);
        input2 = findViewById(R.id.no2);
        tv=findViewById(R.id.textView);
        sharedPreferences=getSharedPreferences("name1", Context.MODE_PRIVATE);

    }

    public void operator(View view) {
        switch (view.getId()) {
            case R.id.add:
                no1 = Double.parseDouble(input1.getText().toString());
                no2 = Double.parseDouble(input2.getText().toString());
                result = no1 + no2;
                break;
            case R.id.sub:
                no1 = Double.parseDouble(input1.getText().toString());
                no2 = Double.parseDouble(input2.getText().toString());
                result = no1 - no2;
                break;
            case R.id.mul:
                no1 = Double.parseDouble(input1.getText().toString());
                no2 = Double.parseDouble(input2.getText().toString());
                result = no1 * no2;
                break;
            case R.id.div:
                no1 = Double.parseDouble(input1.getText().toString());
                no2 = Double.parseDouble(input2.getText().toString());
                result = no1 / no2;
                break;
            case R.id.eq:
               tv.setText(result+"");
        }
    }

    public void trig(View view) {
        no1 = Double.parseDouble(input1.getText().toString());
        double rad=Math.toRadians(no1);
        switch (view.getId()){
            case R.id.sine:
                result=Math.sin(rad);
                break;
            case R.id.cos:
                result=Math.cos(rad);
                break;


        }



    }

    public void memory(View view) {
        switch (view.getId()){
            case R.id.mems:
                editor=sharedPreferences.edit();
                editor.putString(key,result+"");
                editor.commit();
                break;
            case R.id.memr:
                if(sharedPreferences.getAll()!=null)
                {
                    tv.setText(sharedPreferences.getString(key,""));

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"NO data",Toast.LENGTH_SHORT).show();
                }
            case R.id.memc:
                editor=sharedPreferences.edit();
                editor.clear();
                editor.commit();
                break;
        }





    }
}
