import json
size = 8
board = [["_" for x in range(8)] for x in range(8)]

def isSafe(row, col):
  for i in range(col):
    if board[row][i] == "Q":
      return False
  for j in range(row):
    if board[j][col] == "Q":
      return False
  i = row - 1
  j = col - 1
  while i>=0 and j>=0:
    if board[i][j] == "Q":
      return False
    i=i-1
    j=j-1
  i = row + 1
  j = col - 1
  while i<=7 and j>=0:
    if board[i][j] == "Q":
      return False
    i = i + 1
    j = j - 1
  return True


def printBoard():
  for i in range(size):
    for j in range(size):
      print (board[i][j]),
    print ("\n")
    
    
    
def placeQueen(col):
  if col == size:
    print("part")
    printBoard()
    return True
  res = False
  for i in range(size):
    if isSafe(i, col):
      board[i][col] = "Q"
      res = placeQueen(col+1) or res
      board[i][col] = "_"
  return res    

def solveNQ():
    data = []
    with open('input.json') as f:
      data = json.load(f)
    start = data["start"] - 1
    if start<0 and start >8:
      print("Invalid start position")
      return False
    else:  
      print("Before\n")
      board[start][0] = "Q"
      printBoard()
      if placeQueen(1) == False:
          print ("Solution does not exist")
          return False
      return True
solveNQ()  
    
  
  
