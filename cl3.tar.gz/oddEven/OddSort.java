
public class OddSort {
	static String str="";

	public static String sort(int[] intk) {
		int i,j,k;
		for(k=0;k<intk.length;k++)
		{
			if(k%2==0)
			{
				for (i=0;i<intk.length;i+=2)
				{
					if(i!=(intk.length)-1)
					{
						if(intk[i]>intk[i+1])
						{
							int t1;
							t1=intk[i];
							intk[i]=intk[i+1];
							intk[i+1]=t1;
						}
					}
				}
				for(int z=0;z<intk.length;z++)
				{
				
					str+=intk[z]+" ";
				}
				str += "\n		| ";
				
			}
			else{
				for (j=1;j<intk.length;j+=2){
					if(j!=(intk.length)-1)
					{
						if(intk[j]>intk[j+1])
						{
							int t1;
							t1=intk[j];
							intk[j]=intk[j+1];
							intk[j+1]=t1;
						}
					}
				}
				for(int z=0;z<intk.length;z++)
				{
					str+=intk[z]+" ";
				}
				
				str += "\n		| ";
			
						
			
			}
				
			
		
		}
		String a=str;
		str="";
		return a;
		
		
	
	}

}
